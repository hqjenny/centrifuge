package hls_tl0_vgg

import chisel3._
import chisel3.util._
import freechips.rocketchip.unittest.UnitTest
import icenet.IceNetConsts._
import testchipip.{StreamIO, StreamChannel, TLHelper}
import RemoteMemConsts._

class MemBladeParser extends Module {
  val io = IO(new Bundle {
    val netin = Flipped(Decoupled(new StreamChannel(NET_IF_WIDTH)))
    val req_head = Decoupled(new CombinedRequestHeader)
    val req_data = Decoupled(new StreamChannel(NET_IF_WIDTH))
  })

  //val reqHeaderWords = (ETH_HEAD_BYTES + RMEM_REQ_HEAD_BYTES) / NET_IF_BYTES
  val reqHeaderWords = (ETH_HEAD_BYTES) / NET_IF_BYTES
  val reqHeaderVec = Reg(Vec(reqHeaderWords, UInt(NET_IF_WIDTH.W)))
  val reqHeaderIdx = RegInit(0.U(log2Ceil(reqHeaderWords).W))
  val reqHeader = (new CombinedRequestHeader).fromBits(reqHeaderVec.toBits)

  // The parser first collect header, which is of type CombinedRequestHeader
  val s_collect_head :: s_send_head :: s_send_data :: Nil = Enum(3)
  val state = RegInit(s_collect_head)

  io.netin.ready :=
    (state === s_collect_head) ||
    (state === s_send_data && io.req_data.ready)
  io.req_head.valid := state === s_send_head
  io.req_head.bits := reqHeader
  io.req_data.valid := (state === s_send_data) && io.netin.valid
  io.req_data.bits := io.netin.bits

  when (io.netin.fire()) {
    when (state === s_collect_head) {
      reqHeaderVec(reqHeaderIdx) := io.netin.bits.data
      reqHeaderIdx := reqHeaderIdx + 1.U
      // If we read the end of the packet before the full header is read,
      // just drop the packet, since it's wrong
      when (reqHeaderIdx === (reqHeaderWords - 1).U) {
        state := s_send_head
      } .elsewhen (io.netin.bits.last) {
        reqHeaderIdx := 0.U
      }
      // state === s_send_data
    } .elsewhen (io.netin.bits.last) {
      state := s_collect_head
    }
  }

  when (io.req_head.fire()) {
    reqHeaderIdx := 0.U
    // If the request is a write request, send data to the accel
    //state := Mux(reqHeader.rmem.hasData(), s_send_data, s_collect_head)

    // Only accept write request
    state := s_send_data
  }
}

class MemBladeFormatter extends Module {
  val io = IO(new Bundle {
    val resp_head = Flipped(Decoupled(new CombinedResponseHeader))
    val resp_data = Flipped(Decoupled(new StreamChannel(NET_IF_WIDTH)))
    val netout = Decoupled(new StreamChannel(NET_IF_WIDTH))
  })

  val s_collect_head :: s_send_head :: s_send_data :: Nil = Enum(3)
  val state = RegInit(s_collect_head)

  //val respHeaderWords = (ETH_HEAD_BYTES + RMEM_RESP_HEAD_BYTES) / NET_IF_BYTES
  val respHeaderWords = (ETH_HEAD_BYTES) / NET_IF_BYTES
  val respHeader = Reg(new CombinedResponseHeader)
  val respHeaderBits = respHeader.asUInt
  val respHeaderVec = Vec((0 until respHeaderWords).map(
    i => respHeaderBits((i + 1) * NET_IF_WIDTH - 1, i * NET_IF_WIDTH)))
  val (respHeaderIdx, respHeaderDone) = Counter(
    state === s_send_head && io.netout.ready, respHeaderWords)

  io.resp_head.ready := state === s_collect_head
  io.resp_data.ready := (state === s_send_data) && io.netout.ready
  io.netout.valid :=
    (state === s_send_head) ||
    (state === s_send_data && io.resp_data.valid)
  io.netout.bits.data := Mux(state === s_send_head,
    respHeaderVec(respHeaderIdx), io.resp_data.bits.data)
  io.netout.bits.keep := NET_FULL_KEEP
  // Always resp with data
  io.netout.bits.last := Mux((state === s_send_head) || (state === s_collect_head), false.B, io.resp_data.bits.last)
  //io.netout.bits.last := Mux(state === s_send_head,
    //!respHeader.rmem.hasData() && respHeaderIdx === (respHeaderWords-1).U, // If this is not read resp withdata, send ack and set last to 1 onces header is sent
    //respHeaderIdx === (respHeaderWords-1).U,
    //io.resp_data.bits.last)

  //io.netout.bits.last := io.resp_data.bits.last

  when (io.resp_head.fire()) {
    respHeader := io.resp_head.bits
    state := s_send_head
  }
  when (respHeaderDone) {
    //state := Mux(respHeader.rmem.hasData(), s_send_data, s_collect_head)
    state := s_send_data
  }
  when (io.resp_data.fire() && io.resp_data.bits.last) {
    state := s_collect_head
  }
}

class MemBladeProtocolHandler extends Module {
  val io = IO(new Bundle {
    val net = new StreamIO(NET_IF_WIDTH)
    val mb = new MemBladeIO
  })

  // Receive request 
  val parser = Module(new MemBladeParser)
  parser.io.netin <> io.net.in
  io.mb.req_head <> parser.io.req_head
  io.mb.req_data <> parser.io.req_data

  // Send response
  val format = Module(new MemBladeFormatter)
  format.io.resp_head <> io.mb.resp_head
  format.io.resp_data <> io.mb.resp_data
  io.net.out <> format.io.netout
}

class ParserUnitTest extends UnitTest {
  val parser = Module(new MemBladeParser)
  val packetVec = Vec(
    // Ethernet
    0x0.U, ((RMEM_REQ_ETH_TYPE << 48) | 1).U,
    // MB Header
    (RMEM_DRAFT_VERSION | (1 << 8) | (1 << 16) | (0x2L << 32)).U, 0x3.U,
    // MB data
    0.U, 1.U, 2.U, 3.U)
  val (packetIdx, packetDone) = Counter(parser.io.netin.fire(), packetVec.size)
  val (dataIdx, dataDone) = Counter(parser.io.req_data.fire(), 4)

  val s_init :: s_send :: s_done :: Nil = Enum(3)
  val state = RegInit(s_init)

  parser.io.netin.valid := state === s_send
  parser.io.netin.bits.data := packetVec(packetIdx)
  parser.io.netin.bits.keep := DontCare
  parser.io.netin.bits.last := packetIdx === (packetVec.size - 1).U
  parser.io.req_head.ready := true.B
  parser.io.req_data.ready := true.B

  when (state === s_init && io.start) { state := s_send }
  when (packetDone) { state := s_done }

  assert(!parser.io.req_head.valid ||
    (parser.io.req_head.bits.eth.dstmac === 0.U &&
     parser.io.req_head.bits.eth.srcmac === 1.U &&
     parser.io.req_head.bits.eth.ethType === RMEM_REQ_ETH_TYPE.U // &&
   //  parser.io.req_head.bits.rmem.version === RMEM_DRAFT_VERSION.U &&
   //  parser.io.req_head.bits.rmem.opcode  === 1.U &&
   //  parser.io.req_head.bits.rmem.part_id === 1.U &&
   //  parser.io.req_head.bits.rmem.xact_id === 2.U &&
   //  parser.io.req_head.bits.rmem.pageno  === 3.U
    ),
   "ParserUnitTest: incorrect header")

  assert(!parser.io.req_data.valid ||
    parser.io.req_data.bits.data === packetVec(dataIdx + 4.U),
    "ParserUnitTest: incorrect data")

  io.finished := state === s_done
}

class FormatterUnitTest extends UnitTest {
  val format = Module(new MemBladeFormatter)
  val respHead = Wire(new CombinedResponseHeader)
  respHead.eth.padding := 0.U
  respHead.eth.dstmac := 1.U
  respHead.eth.srcmac := 2.U
  respHead.eth.ethType := RMEM_RESP_ETH_TYPE.U
 // respHead.rmem.xact_id := 1.U
 // respHead.rmem.reserved := 0.U
 // respHead.rmem.part_id := 2.U
 // respHead.rmem.resp_code := RMEM_RC_WORD_OK
 // respHead.rmem.version := RMEM_DRAFT_VERSION.U

  val s_init :: s_send_head :: s_send_data :: s_done :: Nil = Enum(4)
  val state = RegInit(s_init)

  format.io.resp_head.valid := state === s_send_head
  format.io.resp_head.bits := respHead
  format.io.resp_data.valid := state === s_send_data
  format.io.resp_data.bits.data := 6.U
  format.io.resp_data.bits.keep := DontCare
  format.io.resp_data.bits.last := true.B
  format.io.netout.ready := true.B

  when (state === s_init && io.start) { state := s_send_head }
  when (format.io.resp_head.fire()) { state := s_send_data }
  when (format.io.resp_data.fire()) { state := s_done }

  val outData = Vec(
    // Ethernet
    (1 << 16).U, ((RMEM_RESP_ETH_TYPE << 48) | 2).U,
    // MB Response
    (RMEM_DRAFT_VERSION | (0x82 << 8) | (2 << 16) | (1L << 32)).U,
    // Word data
    6.U)
  val (outIdx, outDone) = Counter(format.io.netout.fire(), outData.size)
  assert(!format.io.netout.valid ||
    (format.io.netout.bits.data === outData(outIdx) &&
     format.io.netout.bits.last === (outIdx === (outData.size-1).U)),
    "FormatterUnitTest: output incorrect")

  io.finished := state === s_done
}
