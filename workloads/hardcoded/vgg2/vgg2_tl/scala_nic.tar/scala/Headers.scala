package hls_tl0_vgg

import chisel3._
import chisel3.util._
import freechips.rocketchip.util.UIntIsOneOf
import icenet.EthernetHeader
import icenet.IceNetConsts._
import RemoteMemConsts._

object RemoteMemConsts {
  val RMEM_PAGE_SIZE = 4096
  val RMEM_REQ_HEAD_BYTES = 16
  val RMEM_RESP_HEAD_BYTES = 8
  val RMEM_MAX_PART_SIZE = 1368
  val RMEM_NUM_PARTS = 3
  val RMEM_PART_ID_BITS = log2Ceil(RMEM_NUM_PARTS)

  val RMEM_DRAFT_VERSION = 1
  // Actually 0x0804 and 0x0805, but this is network byte order
  val RMEM_REQ_ETH_TYPE = 0x0408L
  val RMEM_RESP_ETH_TYPE = 0x0508L

  val RMEM_OC_PAGE_READ  = 0x0.U(8.W)
  val RMEM_OC_PAGE_WRITE = 0x1.U(8.W)
  val RMEM_OC_WORD_READ  = 0x2.U(8.W)
  val RMEM_OC_WORD_WRITE = 0x3.U(8.W)
  val RMEM_OC_ATOMIC_ADD = 0x4.U(8.W)
  val RMEM_OC_COMP_SWAP  = 0x5.U(8.W)

  val RMEM_RC_PAGE_OK   = 0x80.U(8.W)
  val RMEM_RC_NODATA_OK = 0x81.U(8.W)
  val RMEM_RC_WORD_OK   = 0x82.U(8.W)
  val RMEM_RC_ERROR     = 0x83.U(8.W)
}
import RemoteMemConsts._

class RemoteMemRequestHeader extends Bundle {
  val pageno = UInt(64.W)
  val xact_id = UInt(32.W)
  val reserved = UInt(8.W)
  val part_id = UInt(8.W)
  val opcode = UInt(8.W)
  val version = UInt(8.W)

  def hasData(dummy: Int = 0) =
    opcode =/= RMEM_OC_PAGE_READ

  def isPageSize(dummy: Int = 0) =
    opcode === RMEM_OC_PAGE_READ || opcode === RMEM_OC_PAGE_WRITE

  def isAtomic(dummy: Int = 0) =
    opcode === RMEM_OC_ATOMIC_ADD || opcode === RMEM_OC_COMP_SWAP

  def toWords(w: Int = NET_IF_WIDTH) = {
    val n = (RMEM_REQ_HEAD_BYTES * 8) / w
    this.asTypeOf(Vec(n, UInt(w.W)))
  }
}

class RemoteMemExtendedHeader extends Bundle {
  val reserved2 = UInt(48.W)
  val offset = UInt(12.W)
  val reserved = UInt(2.W)
  val size = UInt(2.W)
}

class RemoteMemResponseHeader extends Bundle {
  val xact_id = UInt(32.W)
  val reserved = UInt(8.W)
  val part_id = UInt(8.W)
  val resp_code = UInt(8.W)
  val version = UInt(8.W)

  def hasData(dummy: Int = 0) =
    resp_code =/= RMEM_RC_NODATA_OK

  def toWords(w: Int = NET_IF_WIDTH) = {
    val n = (RMEM_RESP_HEAD_BYTES * 8) / w
    this.asTypeOf(Vec(n, UInt(w.W)))
  }

  def matches(opcode: UInt): Bool = {
    MuxLookup(resp_code, false.B, Seq(
      RMEM_RC_PAGE_OK -> (opcode === RMEM_OC_PAGE_READ),
      RMEM_RC_WORD_OK -> opcode.isOneOf(
        RMEM_OC_WORD_READ, RMEM_OC_ATOMIC_ADD, RMEM_OC_COMP_SWAP),
      RMEM_RC_NODATA_OK -> opcode.isOneOf(
        RMEM_OC_PAGE_WRITE, RMEM_OC_WORD_WRITE)))
  }
}

object RemoteMemRequestHeader {
  def apply(opcode: UInt, pageno: UInt, xact_id: UInt, part_id: UInt = 0.U) = {
    val header = Wire(new RemoteMemRequestHeader)
    header.pageno := pageno
    header.xact_id := xact_id
    header.part_id := part_id
    header.opcode := opcode
    header.version := RMEM_DRAFT_VERSION.U
    header.reserved := DontCare
    header
  }
}

object RemoteMemExtendedHeader {
  def apply(offset: UInt, size: UInt) = {
    val header = Wire(new RemoteMemExtendedHeader)
    header.offset := offset
    header.size := size
    header.reserved := DontCare
    header.reserved2 := DontCare
    header
  }
}

object RemoteMemResponseHeader {
  def apply(resp_code: UInt, xact_id: UInt, part_id: UInt = 0.U) = {
    val header = Wire(new RemoteMemResponseHeader)
    header.resp_code := resp_code
    header.xact_id := xact_id
    header.part_id := part_id
    header.version := RMEM_DRAFT_VERSION.U
    header.reserved := DontCare
    header
  }

  def apply(request: RemoteMemRequestHeader) = {
    val header = Wire(new RemoteMemResponseHeader)
    header.resp_code := MuxLookup(
      request.opcode, RMEM_RC_ERROR, Seq(
        RMEM_OC_PAGE_READ -> RMEM_RC_PAGE_OK,
        RMEM_OC_PAGE_WRITE -> RMEM_RC_NODATA_OK,
        RMEM_OC_WORD_READ -> RMEM_RC_WORD_OK,
        RMEM_OC_WORD_WRITE -> RMEM_RC_NODATA_OK,
        RMEM_OC_ATOMIC_ADD -> RMEM_RC_WORD_OK,
        RMEM_OC_COMP_SWAP -> RMEM_RC_WORD_OK))
    header.xact_id := request.xact_id
    header.part_id := request.part_id
    header.version := request.version
    header.reserved := DontCare
    header
  }
}

class CombinedRequestHeader extends Bundle {
  //val rmem = new RemoteMemRequestHeader
  val eth = new EthernetHeader

  def toWords(w: Int = NET_IF_WIDTH) =
    eth.toWords(w)
    //VecInit(eth.toWords(w) ++ rmem.toWords(w))
}

class CombinedResponseHeader extends Bundle {
  //val rmem = new RemoteMemResponseHeader
  val eth = new EthernetHeader

  def toWords(w: Int = NET_IF_WIDTH) =
    eth.toWords(w)
    //VecInit(eth.toWords(w) ++ rmem.toWords(w))
}
