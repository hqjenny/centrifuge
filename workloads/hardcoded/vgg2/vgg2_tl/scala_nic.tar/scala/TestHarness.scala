package memblade

import freechips.rocketchip.config.Parameters

class TestHarness(implicit p: Parameters) extends freechips.rocketchip.unittest.TestHarness

object Generator extends freechips.rocketchip.util.GeneratorApp {
  val longName = names.topModuleProject + "." + names.topModuleClass + "." + names.configs
  generateFirrtl
  generateAnno
}
