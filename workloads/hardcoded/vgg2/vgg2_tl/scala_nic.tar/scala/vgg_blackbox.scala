
package hls_vgg
import Chisel._
import freechips.rocketchip.config.{Parameters, Field}
import freechips.rocketchip.tile._
import freechips.rocketchip.util._

class vgg() extends BlackBox() {
	val io = new Bundle {
	}
}
