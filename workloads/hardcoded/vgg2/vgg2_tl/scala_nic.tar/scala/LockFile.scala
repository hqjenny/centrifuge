package memblade

import chisel3._
import chisel3.util._
import freechips.rocketchip.util.UIntIsOneOf
import freechips.rocketchip.config.Parameters
import freechips.rocketchip.unittest.UnitTest

class LockAcquire extends Bundle {
  val pageno = UInt(64.W)
  val rw = Bool()
}

class LockIO extends Bundle {
  val acquire = Decoupled(new LockAcquire)
  val release = Decoupled(Bool())
}

class LockFile(nRequestors: Int)(implicit p: Parameters) extends Module {
  val io = IO(new Bundle {
    val lock = Flipped(Vec(nRequestors, new LockIO))
  })

  val lockInfo = Reg(Vec(nRequestors, new LockAcquire))
  val locked = RegInit(Vec(Seq.fill(nRequestors){false.B}))

  // Build read and write lock request lists separately
  val (canReadLock, canWriteLock) = (0 until nRequestors).map { i =>
    val otherInfo = lockInfo.take(i) ++ lockInfo.drop(i + 1)
    val otherLocked = locked.take(i) ++ locked.drop(i + 1)
    val lockAcq = io.lock(i).acquire.bits

    val (rlockTaken, wlockTaken) = otherInfo.zip(otherLocked).map {
      case (info, locked) =>
        val lockMatch = lockAcq.pageno === info.pageno
        (locked && lockMatch && info.rw, locked && lockMatch)
    }.unzip

    (!rlockTaken.foldLeft(false.B)(_ || _) && io.lock(i).acquire.valid && !lockAcq.rw,
     !wlockTaken.foldLeft(false.B)(_ || _) && io.lock(i).acquire.valid && lockAcq.rw)
  }.unzip

  // Write locks take precedence to prevent starvation
  val rlockOH = PriorityEncoderOH(canReadLock)
  val wlockOH = PriorityEncoderOH(canWriteLock)
  val lockOH = Mux(
    canWriteLock.reduce(_ || _),
    Cat(wlockOH.reverse),
    Cat(rlockOH.reverse))

  for (i <- 0 until nRequestors) {
    io.lock(i).acquire.ready := lockOH(i)
    io.lock(i).release.ready := locked(i)

    when (io.lock(i).acquire.fire()) {
      locked(i) := true.B
      lockInfo(i) := io.lock(i).acquire.bits
    }

    when (io.lock(i).release.fire()) {
      locked(i) := false.B
    }
  }

  for (i <- 0 until (nRequestors - 1)) {
    for (j <- (i + 1) until nRequestors) {
      when (locked(i) && locked(j)) {
        assert(!(lockInfo(i).rw || lockInfo(j).rw) ||
               lockInfo(i).pageno =/= lockInfo(j).pageno,
          "LockFile: write-locked page also locked by other requestors")
      }
    }
  }
}

class LockFileUnitTest(implicit p: Parameters) extends UnitTest {
  val lockfile = Module(new LockFile(2))
  val value = RegInit(0.U(2.W))

  val (s_init :: s_wacq :: s_copy :: s_wback ::
       s_wrel :: s_racq :: s_check :: s_rrel :: s_done :: Nil) = Enum(9)
  val finished = Wire(init = Vec(Seq.fill(2){false.B}))

  for (i <- 0 until 2) {
    val state = RegInit(s_init)
    val local = Reg(UInt(2.W))
    val acq = lockfile.io.lock(i).acquire
    val rel = lockfile.io.lock(i).release
    
    when (state === s_init && io.start) { state := s_wacq }
    when (state === s_wacq && acq.ready) { state := s_copy }
    when (state === s_copy) { local := value; state := s_wback }
    when (state === s_wback) { value := local + 1.U; state := s_wrel }
    when (state === s_wrel && rel.ready) { state := s_racq }
    when (state === s_racq && acq.ready) { state := s_check }
    when (state === s_check) { state := s_rrel }
    when (state === s_rrel && rel.ready) { state := s_done }

    acq.valid := state.isOneOf(s_wacq, s_racq)
    acq.bits.pageno := 0.U
    acq.bits.rw := state === s_wacq
    rel.valid := state.isOneOf(s_wrel, s_rrel)
    rel.bits := DontCare
    finished(i) := state === s_done

    assert(state =/= s_check || value === 2.U,
      "LockFileUnitTest: final value not correct")
  }

  io.finished := finished.reduce(_ && _)
}
